# Báo cáo thử nghiệm B3 — LightGBM, MLP & Đặc trưng đồ thị

## Tổng hợp kết quả (mean ± std qua các seed/fold đã chạy)

| Mô hình | Bộ đặc trưng | PR-AUC | Recall@1% | VDR@1% | Macro PR-AUC | Thời gian (s) |
|---|---|---:|---:|---:|---:|---:|
| lgbm | co_ban | 0.0983 | 0.4508 | 0.0003 | 0.3560 | 74.0 |
| mlp | co_ban | 0.1249 | 0.5260 | 0.0639 | 0.4193 | 342.1 |
| lgbm | do_thi_fl | 0.2325 | 0.5890 | 0.0510 | 0.4713 | 151.1 |
| mlp | do_thi_fl | 0.3569 | 0.6652 | 0.0684 | 0.5611 | 233.7 |
| lgbm | do_thi_nuoc | 0.2720 | 0.6343 | 0.0100 | 0.4976 | 88.7 |
| mlp | do_thi_nuoc | 0.4190 | 0.6939 | 0.0664 | 0.6368 | 247.4 |
| lgbm | do_thi_global | 0.2652 | 0.6387 | 0.9708 | 0.5203 | 91.7 |
| mlp | do_thi_global | 0.3944 | 0.7017 | 0.0669 | 0.5920 | 178.2 |

## Ghi chú tính khả dụng trong Học liên kết (FL)

- **FL-safe 100% (9 cột):** `G_SND_FANOUT_LOG_1D, G_SND_FANOUT_LOG_7D, G_SND_FANIN_LOG_1D, G_SND_FANIN_LOG_7D, G_SND_PASS_1H, G_SND_PASS_1D, G_CYCLE_ABA_LOG_7D, G_PAIR_PAST_LOG_7D, G_SND_APPEAR_LOG` — ngân hàng gửi tự tính hoàn toàn từ tài khoản mình quản lý.
- **Phụ thuộc phạm vi client (9 cột):** `G_RCV_FANIN_LOG_1D, G_RCV_FANIN_LOG_7D, G_RCV_FANOUT_LOG_1D, G_RCV_FANOUT_LOG_7D, G_RCV_PASS_1H, G_RCV_PASS_1D, G_RCV_RECENT_OUT_1H, G_RCV_RECENT_OUT_1D, G_RCV_APPEAR_LOG` — trong `do_thi_bank`/`do_thi_nuoc` chỉ dùng giao dịch liên quan đến client đang xét; trong `do_thi_global` thấy cả giao dịch của tài khoản nhận ở ngân hàng khác (KHÔNG dùng nguyên bản được trong FL thuần túy).
